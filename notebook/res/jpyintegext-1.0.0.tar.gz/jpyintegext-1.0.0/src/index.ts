import {
  JupyterFrontEnd,
  JupyterFrontEndPlugin
} from '@jupyterlab/application';

/**
 * Initialization data for the jpyintegext extension.
 */
const plugin: JupyterFrontEndPlugin<void> = {
  id: 'jpyintegext:plugin',
  description: 'A JupyterLab extension for integrated usage.',
  autoStart: true,
  activate: (app: JupyterFrontEnd) => {
    window.addEventListener('message', event => {
      if (event.data == 'save') {
        console.log("Saving jupyter notebook...");
        app.commands.execute('docmanager:save');
      }
    });
  }
};

export default plugin;
